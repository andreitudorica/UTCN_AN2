#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "a2_helper.h"
#include <pthread.h>

pthread_mutex_t lock1, lock2;
pthread_cond_t cond1, cond2, cond3, cond4, cond5;
int counter, hadt10, leftt10, dcount;
void *fcnt2_3(void *arg)
{
    int tid = *((int *)arg);

    pthread_mutex_lock(&lock1);
    if (tid == 3)
        pthread_cond_wait(&cond1, &lock1);
    if (tid == 4)
        pthread_cond_signal(&cond1);
    info(BEGIN, 6, tid);

    if (tid == 4)
        pthread_cond_wait(&cond2, &lock1);
    if (tid == 3)
        pthread_cond_signal(&cond2);
    info(END, 6, tid);
    pthread_mutex_unlock(&lock1);
    return NULL;
}

void *fcnt2_4(void *arg)
{
    int tid = *((int *)arg);
    pthread_mutex_lock(&lock2);

    if (tid == 10)
        hadt10 = 1;
    if (counter == 4)
        pthread_cond_wait(&cond3, &lock2);
    else
    {
        counter++;
        dcount--;
        info(BEGIN, 7, tid);
        if (counter == 4)
            pthread_cond_signal(&cond4);
    }

    if (tid == 10)
    {
        info(END, 7, tid);
        counter--;
        leftt10 = 1;
    }
    else
    {
        if ((!hadt10 || (hadt10 && !leftt10)) && counter < 4)
            pthread_cond_wait(&cond4, &lock2);

        info(END, 7, tid);
        counter--;
        pthread_cond_signal(&cond3);
    }
    pthread_mutex_unlock(&lock2);
    return NULL;
}

int main(int argc, char **argv)
{
    int pid2, pid3, pid4, pid5, pid6, pid7, pid8;
    int th[40];
    init();
    info(BEGIN, 1, 0);
    pid2 = fork();
    if (pid2 == 0)
    {
        info(BEGIN, 2, 0);
        pid3 = fork();
        if (pid3 == 0)
        {
            info(BEGIN, 3, 0);
            info(END, 3, 0);
        }
        else
        {
            pid4 = fork();
            if (pid4 == 0)
            {
                info(BEGIN, 4, 0);
                info(END, 4, 0);
            }
            else
            {
                pid5 = fork();
                if (pid5 == 0)
                {
                    info(BEGIN, 5, 0);
                    info(END, 5, 0);
                }
                else
                {
                    pid6 = fork();
                    if (pid6 == 0)
                    {
                        info(BEGIN, 6, 0);
                        pthread_t thrd[40];
                        pthread_mutex_init(&lock1, NULL);
                        pthread_cond_init(&cond1, NULL);
                        pthread_cond_init(&cond2, NULL);
                        for (int i = 1; i <= 5; i++)
                        {
                            th[i] = i;
                            pthread_create(&thrd[i], NULL, fcnt2_3, &th[i]);
                        }
                        for (int i = 1; i <= 5; i++)
                            pthread_join(thrd[i], NULL);
                        pthread_mutex_destroy(&lock1);
                        pthread_cond_destroy(&cond1);
                        pthread_cond_destroy(&cond2);
                        info(END, 6, 0);
                    }
                    else
                    {
                        pid8 = fork();
                        if (pid8 == 0)
                        {
                            info(BEGIN, 8, 0);
                            info(END, 8, 0);
                        }
                        else
                        {
                            waitpid(pid3, NULL, 0);
                            waitpid(pid4, NULL, 0);
                            waitpid(pid5, NULL, 0);
                            waitpid(pid6, NULL, 0);
                            waitpid(pid8, NULL, 0);
                            info(END, 2, 0);
                        }
                    }
                }
            }
        }
    }
    else
    {
        pid7 = fork();
        if (pid7 == 0)
        {
            info(BEGIN, 7, 0);
            dcount = 38;
            pthread_t thrd[40];
            pthread_mutex_init(&lock2, NULL);
            pthread_cond_init(&cond3, NULL);
            pthread_cond_init(&cond4, NULL);
            pthread_cond_init(&cond5, NULL);
            for (int i = 1; i <= 38; i++)
            {
                th[i] = i;
                pthread_create(&thrd[i], NULL, fcnt2_4, &th[i]);
            }
            for (int i = 1; i <= 38; i++)
                pthread_join(thrd[i], NULL);
            pthread_mutex_destroy(&lock2);
            pthread_cond_destroy(&cond3);
            pthread_cond_destroy(&cond4);
            pthread_cond_destroy(&cond5);
            info(END, 7, 0);
        }
        else
        {
            waitpid(pid2, NULL, 0);
            waitpid(pid7, NULL, 0);
            info(END, 1, 0);
        }
    }
}