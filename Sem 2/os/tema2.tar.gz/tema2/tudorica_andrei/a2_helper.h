#ifndef __A2_HELPER_H__
#define __A2_HELPER_H__

#define BEGIN 1
#define END 2

void init();
int info(int action, int processNr, int threadNr);

#endif
